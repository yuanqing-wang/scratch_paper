|                |   test |   train |
|:---------------|-------:|--------:|
| TypingAccuracy |      1 |       1 |