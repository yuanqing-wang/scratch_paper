# =============================================================================
# IMPORTS
# =============================================================================
import argparse
import os

import numpy as np
import torch

import espaloma as esp

def run(args):
    # define data
    g = esp.Graph("CN1C=NC2=C1C(=O)N(C(=O)N2C)C")
    data = esp.data.dataset.GraphDataset([g])

    # get force field
    forcefield = esp.graphs.legacy_force_field.LegacyForceField(
        args.forcefield
    )

    # param / typing
    operation = forcefield.typing

    # apply to dataset
    data = data.apply(operation, in_place=True)

    # batch
    ds = data.view("graph", batch_size=1)

    g = next(iter(ds))

    # layer
    layer = esp.nn.layers.dgl_legacy.gn(args.layer)

    # representation
    representation = esp.nn.Sequential(layer, config=args.config)

    # get the last bit of units
    units = [int(x) for x in args.config if isinstance(x, int) or isinstance(x, str) and x.isdigit()][-1]

    # define a readout
    readout = esp.nn.readout.node_typing.NodeTyping(
            in_features=units,
            n_classes=100
    ) # not too many elements here I think?


    net = torch.nn.Sequential(
            representation, 
            readout,
    )


    metrics_tr = [esp.metrics.TypingCrossEntropy()]
    metrics_te = [esp.metrics.TypingAccuracy()]

    if args.opt == "Adam":
        opt = torch.optim.Adam(net.parameters(), 1e-5)

        if args.metric_train == "param":
            opt = torch.optim.Adam(net.parameters(), 1e-1)

    elif args.opt == "SGD":
        opt = torch.optim.SGD(net.parameters(), 1e-5, 1e-5)

    elif args.opt == "LBFGS":
        opt = torch.optim.LBFGS(net.parameters(), 1e-1, line_search_fn="strong_wolfe")

    elif args.opt == "SGLD":
        from pinot.samplers.sgld import SGLD
        opt = SGLD(net.parameters(), 1e-5)

    exp = esp.TrainAndTest(
        ds_tr=ds,
        ds_te=ds,
        net=net,
        metrics_tr=metrics_tr,
        metrics_te=metrics_te,
        n_epochs=args.n_epochs,
        normalize=esp.data.normalize.NotNormalize,
        record_interval=100,
        optimizer=opt,
        device=torch.device('cuda:0'),
    )

    results = exp.run()

    print(esp.app.report.markdown(results))

    import os
    os.mkdir(args.out)

    with open(args.out + "/architecture.txt", "w") as f_handle:
        f_handle.write(str(exp))

    with open(args.out + "/result_table.md", "w") as f_handle:
        f_handle.write(esp.app.report.markdown(results))

    curves = esp.app.report.curve(results)

    for spec, curve in curves.items():
        np.save(args.out + "/" + "_".join(spec) + ".npy", curve)
    
    import pickle
    pickle.dump(
        exp.ref_g_test,
        open(args.out + "/g.th", 'wb'),
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--first", default=-1, type=int)
    parser.add_argument("--partition", default="4:1", type=str)
    parser.add_argument("--batch_size", default=8, type=int)
    parser.add_argument("--forcefield", default="gaff-1.81", type=str)
    parser.add_argument("--layer", default="GraphConv", type=str)
    parser.add_argument("--n_classes", default=100, type=int)
    parser.add_argument(
        "--config", nargs="*", default=[32, "tanh", 32, "tanh", 32, "tanh"]
    )

    parser.add_argument(
        "--training_metrics", nargs="*", default=["TypingCrossEntropy"]
    )
    parser.add_argument(
        "--test_metrics", nargs="*", default=["TypingAccuracy"]
    )
    parser.add_argument(
        "--out", default="results", type=str
    )
    parser.add_argument("--janossy_config", nargs="*", default=[32, "leaky_relu"])

    parser.add_argument("--n_epochs", default=10, type=int)

    parser.add_argument("--opt", default="Adam", type=str)
    parser.add_argument("--metric_train", default="energy", type=str)

    args = parser.parse_args()

    run(args)
