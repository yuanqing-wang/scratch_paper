|                |   test |   train |
|:---------------|-------:|--------:|
| TypingAccuracy |    0.5 |     0.5 |